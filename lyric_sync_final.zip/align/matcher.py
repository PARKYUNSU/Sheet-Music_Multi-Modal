from rapidfuzz import fuzz
from .normalizer_ko import normalize_ko
def token_set_ratio(a:str,b:str)->float:
    A=set(a.split()); B=set(b.split())
    if not A or not B: return 0.0
    return 100.0*(2*len(A&B)/(len(A)+len(B)))
def tail_token_coverage(recent:str,target:str,tail_ratio:float=0.5)->float:
    a=normalize_ko(recent).split(); b=normalize_ko(target).split()
    if not a or not b: return 0.0
    k=max(1,int(len(b)*tail_ratio)); tail=b[-k:]; hit=sum(1 for t in tail if t in a); return hit/len(tail)
class LineMatcher:
    def __init__(self, th_lock=75, th_preview=55, th_release=50):
        self.th_lock=th_lock; self.th_preview=th_preview; self.th_release=th_release; self.locked_line=-1
    def score(self,recent_text:str,target_line:str)->float:
        a=normalize_ko(recent_text); b=normalize_ko(target_line)
        if not a or not b: return 0.0
        pr=fuzz.partial_ratio(a,b); ts=token_set_ratio(a,b); return 0.7*pr+0.3*ts
    def decide(self,recent_text:str,lyrics:list,idx:int):
        curr=lyrics[idx] if idx<len(lyrics) else ''; nxt=lyrics[idx+1] if idx+1<len(lyrics) else ''
        s_curr=self.score(recent_text,curr); s_next=self.score(recent_text,nxt) if nxt else 0.0
        if self.locked_line<idx:
            if s_curr>=self.th_lock: self.locked_line=idx
        else:
            if s_curr<self.th_release: pass
        show_preview=(self.locked_line==idx and s_next>=self.th_preview)
        return self.locked_line, show_preview
