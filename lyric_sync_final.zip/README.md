# Lyric Sync — FINAL (Mac/M2, Church-ready)
실시간 STT(Whisper/Vosk) + 가사 정렬 + 다음 줄 "미리 띄우기" (박자/프로필/GO/HOLD) + Web UI(전체화면/하이라이트)
- 시스템 오디오(BlackHole) 또는 마이크 입력 사용 가능
- 제약 디코딩(Vosk) 및 엄격 순서 모드 지원
- 곡별 프로필(리드 타임/BPM/임계치) 자동 저장/불러오기

설치/실행은 ui/web_server.py 주석 참고.
